# Set working directory
setwd("C:\\Users\\powertec\\Desktop\\IT24101686")

# Check current working directory
getwd()

# Import data
data <- read.table("Exercise - Lab 05.txt", header = TRUE)

# View the data
fix(data)

# Rename the column 
names(data) <- c("Delivery_Time")

# Attach the data
attach(data)

#histogram line
histogram <- hist(Delivery_Time,main = "Histogram of Delivery Times",xlab = "Delivery Time (minutes)",ylab = "Frequency",breaks = seq(20, 70, length.out = 10),right = FALSE)

#part03
# Class limits and frequencies
breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids

# Create class labels
classes <- c()
for(i in 1:(length(breaks) - 1)) {
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

# Frequency distribution table
cbind(Classes = classes, Frequency = freq)

#part4
plot(mids, freq, type = "l",main = "Frequency Polygon for Shareholders", xlab = "Shareholders",ylab = "Frequency",ylim = c(0, max(freq)))

#part5
# Calculate cumulative frequency
cum.freq <- cumsum(freq)

# Create cumulative frequency points
new <- c(0, cum.freq)  # Start with 0 and add cumulative frequencies

# Ensure breaks and new have the same length
plot(breaks, new, type = "l",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Shareholders",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))